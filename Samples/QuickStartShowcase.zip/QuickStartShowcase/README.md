# Quick Start Showcase

This sample project demonstrates a ShowCase that draws an animated scene with the Lua graphics API. It intentionally has no external image, reanimation, particle, or trail assets, so it is easy to inspect and safe to use as a first import test.

Import `Samples/QuickStartShowcase.zip` from the desktop app, open `quickstart_showcase`, and press `Run`.
