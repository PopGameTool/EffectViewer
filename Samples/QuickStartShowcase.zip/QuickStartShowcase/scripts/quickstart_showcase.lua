scene.clear()

local sweep = 0
local pulse = 0

function update(dt, elapsed, frame)
    sweep = (elapsed * 92) % 260
    pulse = 0.5 + math.sin(elapsed * 3.2) * 0.5
end

function draw(g, elapsed, frame)
    g:reset()

    g:set_color(18, 22, 30, 255)
    g:fill_rect(80, 80, 560, 320)

    g:set_color(42, 48, 60, 255)
    g:fill_rect(108, 108, 504, 264)

    g:set_color(64, 156, 214, 230)
    g:fill_rect(126 + sweep, 134, 74, 74)

    g:set_color(72, 200, 150, 220)
    g:fill_rect(170, 262, 112, 54)

    g:set_color(245, 188, 70, 180 + pulse * 70)
    g:fill_rect(304, 228 - pulse * 24, 168, 72)

    g:set_draw_mode("additive")
    g:set_color(255, 110, 84, 80 + pulse * 135)
    g:fill_rect(286, 188, 204, 26)
    g:fill_rect(374, 126, 28, 186)

    g:set_draw_mode("normal")
    g:set_color(232, 238, 246, 210)
    g:fill_rect(118, 348, 300 + pulse * 130, 10)
end

effect.log("Quick Start Showcase loaded")
